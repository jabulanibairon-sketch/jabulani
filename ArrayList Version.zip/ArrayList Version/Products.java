import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Products {
    Products() {
        // constructor which will run the program an object is made
        System.out.println("BRIGHT FUTURE TECHNOLOGIES APPLICATION");
        System.out.println("***************************************");
        while (true) {
            System.out.println("");
            System.out.print("Enter (1) to launch menu or any other key to exit ");
            String value = s.nextLine();
            System.out.println("");
            if ("1".equals(value.trim())) {
                switch (DisplayMenu()) {
                    case 1 -> CaptureProduct();
                    case 2 -> SearchProduct();
                    case 3 -> UpdateProduct();
                    case 4 -> DeleteProduct();
                    case 5 -> PrintProductReport();
                    case 6 -> Exit();
                }
            } else {
                Exit();
            }
        }
    }


    //making these static so i can use them in the static methods without creating an object inside of every method
    private static Scanner s = new Scanner(System.in);//used to get user input
    private static ArrayList<ReportData> list = new ArrayList<>();//stores our products

    public static int DisplayMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new product.");
        System.out.println("(2) Search for a product.");
        System.out.println("(3) Update a product.");
        System.out.println("(4) Delete a product.");
        System.out.println("(5) Print report.");
        System.out.println("(6) Exit Application.");
        int choice = 0;
        System.out.print("choice >> ");
        while (true) {
            try {
                choice = s.nextInt();
                s.nextLine();
                if (!(choice > 0 && choice < 7)) {
                    System.out.print("Choice must be between 1 and 6");
                    continue;
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a number between 1 and 6.");
                s.nextLine();//getting an int as input so i have to clear the buffer so it doesn't get stuck in an infinite loop
                continue;
            }
            System.out.println("");
            return choice;
        }
    }

    public static void CaptureProduct() {
        System.out.println("CAPTURE A NEW PRODUCT");
        System.out.println("**************************");

        System.out.print("Enter the product code: ");
        String prodCode = s.nextLine().trim();

        while(true){
            if(prodCode.isEmpty()){
                System.out.println("Product code cannot be empty");
                System.out.print("Enter the product code: ");
                prodCode = s.nextLine().trim();
            }
            else{
                break;
            }
        }
        
            for (ReportData product : list) {
                if (product.getProductCode().equalsIgnoreCase(prodCode)) {
                    System.out.println("Product " + product.getProductName() + " is already in the system");
                    return;
                }
            }

        String prodName;
        while (true) {
            System.out.print("Enter the product name: ");
            prodName = s.nextLine().trim();
            if (!prodName.isEmpty()) {
                break;
            }
            System.out.println("Product name cannot be empty");
        }

        System.out.println("");
        System.out.println("Select the product category:");
        System.out.println("Desktop Computer - 1");
        System.out.println("Laptop - 2");
        System.out.println("Tablet - 3");
        System.out.println("Printer - 4");
        System.out.println("Gaming Console - 5");
        System.out.print("Product category >> ");

        int category ;
        while (true) {
            try {
                category = s.nextInt();
                s.nextLine();
                if (category < 1 || category > 5) {
                    System.out.println("Category has to be between 1 and 5");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Input has to be a valid number, 1-5");
                s.nextLine();
            }
        }

        System.out.println("");
        System.out.print("Indicate the product warranty. Enter (1) for 6 months or any other key for 2 years. ");
        String warranty = s.nextLine();
        double warrantyMonths;
        if("1".equals(warranty.trim())){
            warrantyMonths = 6.0;
        }
        else{
            warrantyMonths = 24.0;
        }

        System.out.println("");
        System.out.print("Enter the price for " + prodName + " >> ");
        double price;
        while (true) {
            try {
                price = s.nextDouble();
                s.nextLine();
                if(price<0){
                    System.out.println("Price cannot be NEGATIVE!!!!"); 
                    System.out.print("Enter price >> ");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Price is supposed to be a valid numeric calculation format.");
                s.nextLine();
                System.out.print("Enter price >> ");
            }
        }

        int stock;
        while (true) {
            try {
                System.out.print("Enter Stock level for " + prodName + " >> ");
                stock = s.nextInt();
                s.nextLine();
                if (stock < 0) {
                    System.out.println("Stock cannot be negative");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Input has to be a valid number.");
                s.nextLine();
            }
        }
            
        String supplier;
        while (true) {
            System.out.print("Enter the supplier for " + prodName + " >> ");
            supplier = s.nextLine().trim();
            if (!supplier.isEmpty()) {
                break;
            }
            System.out.println("Supplier cannot be empty");
        }

        ReportData obj = new ReportData(prodCode, prodName, warrantyMonths, category, price, stock, supplier);
        SaveProduct(obj);
    }
    public static void SaveProduct(ReportData obj) {
        if (obj != null) {
            list.add(obj);
            System.out.println("Product details has been saved successfully!!!");
        }
    }

    public static void SearchProduct() {
        String prodCode;
        while (true) {
            System.out.print("Please enter the product code to search: ");
            prodCode = s.nextLine().trim();
            if (!prodCode.isEmpty()) {
                break;
            }
            System.out.println("Product code cannot be empty");
        }
        
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getProductCode().equalsIgnoreCase(prodCode)) {
                ReportData obj = list.get(i);
                System.out.println("*************************************************");
                System.out.println("PRODUCT SEARCH RESULTS");
                System.out.println("*************************************************");
                System.out.println("PRODUCT CODE: " + obj.getProductCode());
                System.out.println("PRODUCT NAME: " + obj.getProductName());
                System.out.println("PRODUCT WARRANTY: " + (obj.getWarranty() / 12) + " years");
                System.out.println("PRODUCT CATEGORY: " + CategName(obj.getCategory()));
                System.out.println("PRODUCT PRICE: " + obj.getPrice());
                System.out.println("PRODUCT STOCK LEVELS: " + obj.getStockLevels());
                System.out.println("PRODUCT SUPPLIER: " + obj.getSupplier());
                return;
            }   
        }
        System.out.println("The product cannot be located. Invalid Product");
    }

    public static void DeleteProduct(){

        String prodCode;//so it's not destroyed after the loop
        while (true) {
            System.out.print("Please enter the product code to delete: ");
            prodCode = s.nextLine().trim();
            if (!prodCode.isEmpty()) {
                break;
            }
            System.out.println("Product code cannot be empty");
        }
        boolean found = false;

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getProductCode().equalsIgnoreCase(prodCode)) {
                found = true;
                System.out.println("Are you sure that you want to delete? (y) for yes, any other key to cancel");
                String confirm = s.nextLine();

                if("y".equalsIgnoreCase(confirm.trim())){
                    list.remove(i);
                    System.out.println("Product deleted successfully");
                }
                else{
                    System.out.println("Cancellation successful");
                }

                break;
            }
        }

        if(!found){
            System.out.println("The product was not found in the system");
        }

    }
   
    public static void UpdateProduct() {
        String prodCode;
        while (true) {
            System.out.print("Please enter the product code to update: ");
            prodCode = s.nextLine().trim();
            if (!prodCode.isEmpty()) {
                break;
            }
            System.out.println("Product code cannot be empty");
        }
        boolean found = false;

        for (int i = 0; i < list.size(); i++) {
            ReportData product = list.get(i);
            if (product.getProductCode().equalsIgnoreCase(prodCode)) {
                found = true;

                System.out.print("Update the warranty? (y) Yes, (n) No ");
                while (true) {
                    String warrInput = s.nextLine().trim().toLowerCase();
                    if (warrInput.isEmpty()) {
                        System.out.print("Please enter 'y' or 'n': ");
                        continue;
                    }
                    char warr = warrInput.charAt(0);

                    if (warr == 'y') {
                        System.out.print("Indicate the new product warranty. Enter (1) for 6 months or any other key for 2 years. ");
                        String warranty = s.nextLine();
                        if("1".equals(warranty.trim())){
                            product.setWarranty(6.0);
                        }
                        else{
                            product.setWarranty(24.0);
                        }
                        break;
                    }
                    else if (warr == 'n') {
                        System.out.println("It won't be changed then");
                        break;
                    }
                    else{
                        System.out.print("Invalid character entered! Try again (y/n): ");
                    }
                }

                System.out.print("Update the price? (y) Yes, (n) No ");
                while (true) {
                    String priceInput = s.nextLine().trim().toLowerCase();
                    if (priceInput.isEmpty()) {
                        System.out.print("Please enter 'y' or 'n': ");
                        continue;
                    }
                    char price = priceInput.charAt(0);

                    if (price == 'y') {
                        while (true) {
                            try{
                                System.out.print("Enter the new price for " + product.getProductName() + " >> ");
                                double p = s.nextDouble();
                                s.nextLine();
                                product.setPrice(p);
                                break;
                            }
                            catch(InputMismatchException e){
                                System.out.println("Price has to be a number.");
                                s.nextLine();
                            }
                        }
                        break;
                    }
                    else if (price == 'n') {
                        System.out.println("Okay, Moving on");
                        break;
                    }
                    else{
                        System.out.print("Invalid character entered! Try again (y/n): ");
                    }
                }

                System.out.print("Update the stock level? (y) Yes, (n) No ");
                while (true) {
                    String choiceInput = s.nextLine().trim().toLowerCase();

                    if (choiceInput.isEmpty()) {
                        System.out.print("Please enter 'y' or 'n': ");
                        continue;
                    }

                    char stock = choiceInput.charAt(0);

                    if (stock == 'y') {
                        while (true) {
                            System.out.print("Enter the new stock level for " + product.getProductName() + " >> ");
                            try{
                                int st = s.nextInt();
                                s.nextLine();

                                if(st >= 0){
                                    product.setStockLevels(st);
                                    break;
                                }
                                else{
                                    System.out.println("Stock cannot be negative.");
                                }
                            }
                            catch(InputMismatchException e){
                                System.out.println("You should enter only valid integers(1,2,..etc).");
                                s.nextLine();
                            }
                        }
                        break;
                    }
                    else if (stock == 'n') {
                        System.out.println("Stock level was not changed.");
                        break;
                    }
                    else{
                        System.out.print("Invalid character entered! Enter (y) for Yes or (n) for No: ");
                    }
                }

                System.out.println("Product details updated successfully.");
                break;
            }
        }

        if (!found) {
            System.out.println("Product not found");
        }
    }

    public static void PrintProductReport() {
        System.out.println("PRODUCT REPORT");
        System.out.println("=====================================================================================");

        if (list.isEmpty()) {
            System.out.println("No products available.");
            System.out.println("");
            return;
        }

        double total = 0.0;
        for (int i = 0; i < list.size(); i++) {
            ReportData product = list.get(i);
            double itemTimesStock = product.getPrice() * product.getStockLevels();
            total += itemTimesStock;
            System.out.println("PRODUCT " + (i + 1));
            System.out.println("-------------------------------------------------------------------------------------");
            System.out.println("PRODUCT CODE >> " + product.getProductCode());
            System.out.println("PRODUCT NAME >> " + product.getProductName());
            System.out.println("PRODUCT WARRANTY >> " + (product.getWarranty() / 12) + " years");
            System.out.println("PRODUCT CATEGORY >> " + CategName(product.getCategory()));
            System.out.println("PRODUCT PRICE >> " + product.getPrice());
            System.out.println("PRODUCT STOCK LEVELS >> " + product.getStockLevels());
            System.out.println("PRODUCT SUPPLIER >> " + product.getSupplier());
            System.out.println("-------------------------------------------------------------------------------------");
        }

        
        System.out.println("==================================================================================");
        System.out.println("TOTAL PRODUCT COUNT: " + list.size());
        System.out.println("TOTAL PRODUCT VALUE: R " + total);
        System.out.println("AVERAGE PRODUCT VALUE: R " + (total / list.size()));
        System.out.println("==================================================================================");
    }

    public static void Exit() {
        System.out.println("END,Have a great day!");
        System.exit(0);
    }
     public static String CategName(int category){
        switch(category){
            case 1:
                return "Desktop Computer";
            case 2:
                return "Laptop";
            case 3:
                return "Tablet";
            case 4:
                return "Printer";
            case 5:
                return "Gaming Console";
            default:
                return "Unknown";// won't ever be used but just in case
        }
    }
}
